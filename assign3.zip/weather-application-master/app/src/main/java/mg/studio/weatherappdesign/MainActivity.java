package mg.studio.weatherappdesign;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new DownloadUpdate().execute();
        //get the system time
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss");
        Date curDate = new Date(System.currentTimeMillis());
        String str = formatter.format(curDate);
        Log.d("curdate time:", str);
        TextView text_curtime = (TextView) this.findViewById(R.id.tv_date);
        text_curtime.setText(str);

        //set next four days
        SimpleDateFormat format = new SimpleDateFormat("EEEE");
        Date curdate = new Date(System.currentTimeMillis());

        String curstr = format.format(curDate);
        int numberInWeek = getNumberInWeek(curstr);
        Log.d("curstr", curstr);
        Log.d("curstr inter", String.valueOf(numberInWeek));
        setSpecificTime(numberInWeek);

        String today = format.format(curdate);
        Log.i("EEEE", today);
        TextView time2time = (TextView) this.findViewById(R.id.today_is_whatday);
        time2time.setText(today);
    }
    public int getNumberInWeek(String str) {
        int number = 0;
        switch (str) {
            case "Sunday":
                number = 7;
                break;
            case "Saturday":
                number = 6;
                break;
            case "Friday":
                number = 5;
                break;
            case "Thursday":
                number = 4;
                break;
            case "Wednesday":
                number = 3;
                break;
            case "Tuesday":
                number = 2;
                break;
            case "Monday":
                number = 1;
                break;
            default:
                break;
        }
        return number;
    }
    public String getStringInWeek(int t) {
        String whatday = null;
        switch (t) {
            case 0:
                whatday = "SUN";
                break;
            case 1:
                whatday = "MON";
                break;
            case 2:
                whatday = "TUE";
                break;
            case 3:
                whatday = "WED";
                break;
            case 4:
                whatday = "THU";
                break;
            case 5:
                whatday = "FRI";
                break;
            case 6:
                whatday = "SAT";
                break;
            default:
                break;
        }
        return whatday;
    }
    public void setSpecificTime(int i) {
        int time2 = i + 1;
        time2 = time2 % 7;
        String time2string = getStringInWeek(time2);
        Log.i("time2锛�", time2string);
        TextView time2time = (TextView) this.findViewById(R.id.tf1);
        time2time.setText(time2string);

        int time3 = i + 2;
        time3 = time3 % 7;
        String time3string = getStringInWeek(time3);
        Log.i("time3锛�", time3string);
        TextView time3time = (TextView) this.findViewById(R.id.tf2);
        time3time.setText(time3string);

        int time4 = i + 3;
        time4 = time4 % 7;
        String time4string = getStringInWeek(time4);
        Log.i("time4锛�", time4string);
        TextView time4time = (TextView) this.findViewById(R.id.tf3);
        time4time.setText(time4string);

        int time5 = i + 4;
        time5 = time5 % 7;
        String time5string = getStringInWeek(time5);
        TextView time5time = (TextView) this.findViewById(R.id.tf4);
        time5time.setText(time5string);
    }

    public void btnClick(View view) {
        new DownloadUpdate().execute();
    }


    private class DownloadUpdate extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... strings) {
            String stringUrl = "http://t.weather.sojson.com/api/weather/city/101040100";
            HttpURLConnection urlConnection = null;
            BufferedReader reader;

            try {
                URL url = new URL(stringUrl);

                // Create the request to get the information from the server, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Mainly needed for debugging
                    Log.d("TAG", line);
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                //The temperature
                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
        @Override
        protected void onPostExecute(String buffer) {
            //Update the temperature displayed
            //buffer.toString();

            String date;
            String tf[] = new String[5];
            String ltf[] = new String[5];
            //String df[] = new String[5];
            String pic[] = new String[5];

            JsonParser parser = new JsonParser();  //创建JSON解析器
            JsonObject object = (JsonObject) parser.parse(buffer);

            //date = object.get("time").getAsString();
            JsonObject objectdata = object.get("data").getAsJsonObject();
            JsonArray array = objectdata.get("forecast").getAsJsonArray();
            for (int i = 0; i <= 4; i++) {
                //System.out.println("---------------");
                JsonObject subObject = array.get(i).getAsJsonObject();
                tf[i] = subObject.get("high").getAsString();
                ltf[i] = subObject.get("low").getAsString();
                pic[i] = subObject.get("type").getAsString();
                //System.out.println(pic[i]);
            }

            ((TextView) findViewById(R.id.tf0)).setText(tf[0]);
            //((TextView) findViewById(R.id.tv_date)).setText(date);

            ((TextView) findViewById(R.id.df1)).setText(tf[1]);
            ((TextView) findViewById(R.id.df2)).setText(tf[2]);
            ((TextView) findViewById(R.id.df3)).setText(tf[3]);
            ((TextView) findViewById(R.id.df4)).setText(tf[4]);

            ((TextView) findViewById(R.id.ltf0)).setText(ltf[0]);
            ((TextView) findViewById(R.id.ltf1)).setText(ltf[1]);
            ((TextView) findViewById(R.id.ltf2)).setText(ltf[2]);
            ((TextView) findViewById(R.id.ltf3)).setText(ltf[3]);
            ((TextView) findViewById(R.id.ltf4)).setText(ltf[4]);

            int i = 0;
            while (i <= 4) {
                switch (pic[i]) {
                    case "多云":{
                        if(i==0)
                            findViewById(R.id.pic0).setBackgroundResource(R.drawable.partly_sunny_small);
                        if(i==1)
                            findViewById(R.id.pic1).setBackgroundResource(R.drawable.partly_sunny_small);
                        if(i==2)
                            findViewById(R.id.pic2).setBackgroundResource(R.drawable.partly_sunny_small);
                        if(i==3)
                            findViewById(R.id.pic3).setBackgroundResource(R.drawable.partly_sunny_small);
                        if(i==4)
                            findViewById(R.id.pic4).setBackgroundResource(R.drawable.partly_sunny_small);
                    }
                    case "阴": {
                        if(i==0)
                            findViewById(R.id.pic0).setBackgroundResource(R.drawable.windy_small);
                        if(i==1)
                            findViewById(R.id.pic1).setBackgroundResource(R.drawable.windy_small);
                        if(i==2)
                            findViewById(R.id.pic2).setBackgroundResource(R.drawable.windy_small);
                        if(i==3)
                            findViewById(R.id.pic3).setBackgroundResource(R.drawable.windy_small);
                        if(i==4)
                            findViewById(R.id.pic4).setBackgroundResource(R.drawable.windy_small);
                    }
                    break;
                    case "晴": {
                        if(i==0)
                            findViewById(R.id.pic0).setBackgroundResource(R.drawable.sunny_small);
                        if(i==1)
                            findViewById(R.id.pic1).setBackgroundResource(R.drawable.sunny_small);
                        if(i==2)
                            findViewById(R.id.pic2).setBackgroundResource(R.drawable.sunny_small);
                        if(i==3)
                            findViewById(R.id.pic3).setBackgroundResource(R.drawable.sunny_small);
                        if(i==4)
                            findViewById(R.id.pic4).setBackgroundResource(R.drawable.sunny_small);
                    }
                    break;
                    case "小雨": {
                        if(i==0)
                            findViewById(R.id.pic0).setBackgroundResource(R.drawable.rainy_small);
                        if(i==1)
                            findViewById(R.id.pic1).setBackgroundResource(R.drawable.rainy_small);
                        if(i==2)
                            findViewById(R.id.pic2).setBackgroundResource(R.drawable.rainy_small);
                        if(i==3)
                            findViewById(R.id.pic3).setBackgroundResource(R.drawable.rainy_small);
                        if(i==4)
                            findViewById(R.id.pic4).setBackgroundResource(R.drawable.rainy_small);
                    }
                    break;
                }
                i++;
            }
        }
    }
}
